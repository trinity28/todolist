<hr/>

<div class="container">
    &copy; {{ date('Y') }}, <a href="#">lovely</a>
    <br/>
</div>